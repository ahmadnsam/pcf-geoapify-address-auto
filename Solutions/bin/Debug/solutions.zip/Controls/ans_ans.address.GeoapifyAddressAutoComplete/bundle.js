var pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad =
/******/ (function(modules) { // webpackBootstrap
/******/ 	// The module cache
/******/ 	var installedModules = {};
/******/
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/
/******/ 		// Check if module is in cache
/******/ 		if(installedModules[moduleId]) {
/******/ 			return installedModules[moduleId].exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = installedModules[moduleId] = {
/******/ 			i: moduleId,
/******/ 			l: false,
/******/ 			exports: {}
/******/ 		};
/******/
/******/ 		// Execute the module function
/******/ 		modules[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/
/******/ 		// Flag the module as loaded
/******/ 		module.l = true;
/******/
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/
/******/
/******/ 	// expose the modules object (__webpack_modules__)
/******/ 	__webpack_require__.m = modules;
/******/
/******/ 	// expose the module cache
/******/ 	__webpack_require__.c = installedModules;
/******/
/******/ 	// define getter function for harmony exports
/******/ 	__webpack_require__.d = function(exports, name, getter) {
/******/ 		if(!__webpack_require__.o(exports, name)) {
/******/ 			Object.defineProperty(exports, name, { enumerable: true, get: getter });
/******/ 		}
/******/ 	};
/******/
/******/ 	// define __esModule on exports
/******/ 	__webpack_require__.r = function(exports) {
/******/ 		if(typeof Symbol !== 'undefined' && Symbol.toStringTag) {
/******/ 			Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });
/******/ 		}
/******/ 		Object.defineProperty(exports, '__esModule', { value: true });
/******/ 	};
/******/
/******/ 	// create a fake namespace object
/******/ 	// mode & 1: value is a module id, require it
/******/ 	// mode & 2: merge all properties of value into the ns
/******/ 	// mode & 4: return value when already ns object
/******/ 	// mode & 8|1: behave like require
/******/ 	__webpack_require__.t = function(value, mode) {
/******/ 		if(mode & 1) value = __webpack_require__(value);
/******/ 		if(mode & 8) return value;
/******/ 		if((mode & 4) && typeof value === 'object' && value && value.__esModule) return value;
/******/ 		var ns = Object.create(null);
/******/ 		__webpack_require__.r(ns);
/******/ 		Object.defineProperty(ns, 'default', { enumerable: true, value: value });
/******/ 		if(mode & 2 && typeof value != 'string') for(var key in value) __webpack_require__.d(ns, key, function(key) { return value[key]; }.bind(null, key));
/******/ 		return ns;
/******/ 	};
/******/
/******/ 	// getDefaultExport function for compatibility with non-harmony modules
/******/ 	__webpack_require__.n = function(module) {
/******/ 		var getter = module && module.__esModule ?
/******/ 			function getDefault() { return module['default']; } :
/******/ 			function getModuleExports() { return module; };
/******/ 		__webpack_require__.d(getter, 'a', getter);
/******/ 		return getter;
/******/ 	};
/******/
/******/ 	// Object.prototype.hasOwnProperty.call
/******/ 	__webpack_require__.o = function(object, property) { return Object.prototype.hasOwnProperty.call(object, property); };
/******/
/******/ 	// __webpack_public_path__
/******/ 	__webpack_require__.p = "";
/******/
/******/
/******/ 	// Load entry module and return exports
/******/ 	return __webpack_require__(__webpack_require__.s = "./GeoapifyAddressAutoComplete/index.ts");
/******/ })
/************************************************************************/
/******/ ({

/***/ "./GeoapifyAddressAutoComplete/index.ts":
/*!**********************************************!*\
  !*** ./GeoapifyAddressAutoComplete/index.ts ***!
  \**********************************************/
/*! no static exports found */
/***/ (function(module, exports, __webpack_require__) {

"use strict";
eval("\n\nObject.defineProperty(exports, \"__esModule\", {\n  value: true\n});\nexports.GeoapifyAddressAutoComplete = void 0;\n\nvar GeoapifyAddressAutoComplete =\n/** @class */\nfunction () {\n  function GeoapifyAddressAutoComplete() {}\n  /**\r\n   * Used to initialize the control instance. Controls can kick off remote server calls and other initialization actions here.\r\n   * Data-set values are not initialized here, use updateView.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to property names defined in the manifest, as well as utility functions.\r\n   * @param notifyOutputChanged A callback method to alert the framework that the control has new outputs ready to be retrieved asynchronously.\r\n   * @param state A piece of data that persists in one session for a single user. Can be set at any point in a controls life cycle by calling 'setControlState' in the Mode interface.\r\n   * @param container If a control is marked control-type='standard', it will receive an empty div element within which it can render its content.\r\n   */\n\n\n  GeoapifyAddressAutoComplete.prototype.init = function (context, notifyOutputChanged, state, container) {\n    // Add control initialization code\n    this._context = context;\n    this._notifyOutputChanged = notifyOutputChanged;\n    this.langCode = this.getLangCode(this._context.userSettings.languageId);\n    this.apiKey = this._context.parameters.apiKey ? this._context.parameters.apiKey.raw : \"\";\n    this.countryCodes = this._context.parameters.countryCodes && this._context.parameters.countryCodes.raw ? this._context.parameters.countryCodes.raw : \"\";\n    this.searchContainer = document.createElement(\"div\");\n    this.searchContainer.className = \"autocomplete-container\";\n    this.searchContainer.id = \"autocomplete-container\";\n    container.appendChild(this.searchContainer); //initiate the Geoapify control build and logic\n\n    this.addressAutocomplete(this.searchContainer, function (data) {\n      return;\n    }, {\n      placeholder: context.resources.getString(\"placeholderLbl\")\n    }, this);\n    var spaceElement = document.createElement(\"div\");\n    spaceElement.innerHTML += \"</br>\";\n    container.appendChild(spaceElement);\n  };\n\n  GeoapifyAddressAutoComplete.prototype.getLangCode = function (lang) {\n    switch (lang) {\n      case 1025:\n        return \"ar\";\n\n      case 1031:\n        return \"de\";\n\n      case 1033:\n        return \"en\";\n\n      case 1035:\n        return \"fi\";\n\n      case 1036:\n        return \"fr\";\n\n      case 1040:\n        return \"it\";\n\n      case 1043:\n        return \"nl\";\n\n      case 3082:\n        return \"es\";\n\n      default:\n        return \"\";\n    }\n  };\n  /**\r\n   * Called when any value in the property bag has changed. This includes field values, data-sets, global values such as container height and width, offline status, control metadata values such as label, visible, etc.\r\n   * @param context The entire property bag available to control via Context Object; It contains values as set up by the customizer mapped to names defined in the manifest, as well as utility functions\r\n   */\n\n\n  GeoapifyAddressAutoComplete.prototype.updateView = function (context) {};\n  /**\r\n   * It is called by the framework prior to a control receiving new data.\r\n   * @returns an object based on nomenclature defined in manifest, expecting object[s] for property marked as “bound” or “output”\r\n   */\n\n\n  GeoapifyAddressAutoComplete.prototype.getOutputs = function () {\n    return {\n      address_country: this.add_country_val,\n      address_state: this.add_state_val,\n      address_city: this.add_city_val,\n      address_zipcode: this.add_zipcode_val,\n      address_street1: this.add_street1_val,\n      address_street2: this.add_street2_val\n    };\n  };\n  /**\r\n   * Called when the control is to be removed from the DOM tree. Controls should use this call for cleanup.\r\n   * i.e. cancelling any pending remote calls, removing listeners, etc.\r\n   */\n\n\n  GeoapifyAddressAutoComplete.prototype.destroy = function () {// Add code to cleanup control if necessary\n  };\n\n  GeoapifyAddressAutoComplete.prototype.updateFields = function (geoApifyProperties) {\n    this.add_country_val = geoApifyProperties.country ? geoApifyProperties.country : \"\";\n    this.add_state_val = geoApifyProperties.state ? geoApifyProperties.state : \"\";\n    this.add_city_val = geoApifyProperties.city ? geoApifyProperties.city : \"\";\n    this.add_zipcode_val = geoApifyProperties.postcode ? geoApifyProperties.postcode : \"\";\n    this.add_street1_val = geoApifyProperties.address_line1 ? geoApifyProperties.address_line1 : \"\";\n    this.add_street2_val = geoApifyProperties.address_line2 ? geoApifyProperties.address_line2 : \"\";\n\n    this._notifyOutputChanged();\n  }; //Below the Geoapify JS function\n\n\n  GeoapifyAddressAutoComplete.prototype.addressAutocomplete = function (containerElement, callback, options, _this) {\n    // create input element\n    var inputElement = document.createElement(\"input\");\n    inputElement.setAttribute(\"type\", \"text\");\n    inputElement.setAttribute(\"placeholder\", options.placeholder);\n    _this.inputSearchElement = inputElement;\n    containerElement ? containerElement.appendChild(inputElement) : null; // add input field clear button\n\n    var clearButton = document.createElement(\"div\");\n    clearButton.classList.add(\"clear-button\");\n    addIcon(clearButton);\n    clearButton.addEventListener(\"click\", function (e) {\n      e.stopPropagation();\n      inputElement.value = '';\n      callback(null);\n      clearButton.classList.remove(\"visible\");\n      closeDropDownList();\n    });\n    containerElement ? containerElement.appendChild(clearButton) : null;\n    /* Current autocomplete items data (GeoJSON.Feature) */\n\n    var currentItems;\n    /* Active request promise reject function. To be able to cancel the promise when a new request comes */\n\n    var currentPromiseReject;\n    /* Focused item in the autocomplete list. This variable is used to navigate with buttons */\n\n    var focusedItemIndex;\n    /* Execute a function when someone writes in the text field: */\n\n    inputElement.addEventListener(\"input\", function (e) {\n      var currentValue = this.value;\n      /* Close any already open dropdown list */\n\n      closeDropDownList(); // Cancel previous request promise\n\n      if (currentPromiseReject) {\n        currentPromiseReject({\n          canceled: true\n        });\n      }\n\n      if (!currentValue) {\n        clearButton.classList.remove(\"visible\");\n        return false;\n      } // Show clearButton when there is a text\n\n\n      clearButton.classList.add(\"visible\");\n      /* Create a new promise and send geocoding request */\n\n      var promise = new Promise(function (resolve, reject) {\n        currentPromiseReject = reject; //var apiKey = \"47f523a46b944b47862e39509a7833a9\";\n\n        var apiKey = _this.apiKey;\n        var url = \"https://api.geoapify.com/v1/geocode/autocomplete?text=\" + encodeURIComponent(currentValue) + \"&limit=5&apiKey=\" + apiKey;\n\n        if (_this.countryCodes !== \"\") {\n          url += \"&filter=countrycode:\" + _this.countryCodes;\n        }\n\n        if (_this.langCode !== \"\") {\n          url += \"&lang=\" + _this.langCode;\n        }\n\n        if (options.type) {\n          url += \"&type=\" + options.type;\n        }\n\n        fetch(url, {\n          method: 'GET',\n          mode: 'cors',\n          cache: 'no-cache',\n          credentials: 'same-origin',\n          headers: {\n            'Content-Type': 'application/json'\n          },\n          redirect: 'follow',\n          referrerPolicy: 'no-referrer'\n        }).then(function (response) {\n          // check if the call was successful\n          if (response.ok) {\n            response.json().then(function (data) {\n              return resolve(data);\n            });\n          } else {\n            response.json().then(function (data) {\n              return reject(data);\n            });\n          }\n        });\n      });\n      promise.then(function (data) {\n        currentItems = data.features;\n        /*create a DIV element that will contain the items (values):*/\n\n        var autocompleteItemsElement = document.createElement(\"div\");\n        autocompleteItemsElement.style.position = \"relative\";\n        autocompleteItemsElement.setAttribute(\"class\", \"autocomplete-items\");\n        containerElement ? containerElement.appendChild(autocompleteItemsElement) : null;\n        /* For each item in the results */\n\n        data.features.forEach(function (feature, index) {\n          /* Create a DIV element for each element: */\n          var itemElement = document.createElement(\"DIV\");\n          /* Set formatted address as item value */\n\n          itemElement.innerHTML = feature.properties.formatted;\n          /* Set the value for the autocomplete text field and notify: */\n\n          itemElement.addEventListener(\"click\", function (e) {\n            inputElement.value = currentItems[index].properties.formatted; //place your code here when the option is clicked\n\n            _this.updateFields(currentItems[index].properties);\n\n            callback(currentItems[index]);\n            /* Close the list of autocompleted values: */\n\n            closeDropDownList();\n          });\n          autocompleteItemsElement.appendChild(itemElement);\n        });\n      }, function (err) {\n        if (!err.canceled) {\n          console.log(err);\n        }\n      });\n    });\n    /* Add support for keyboard navigation */\n\n    inputElement.addEventListener(\"keydown\", function (e) {\n      var autocompleteItemsElement = containerElement ? containerElement.querySelector(\".autocomplete-items\") : null;\n\n      if (autocompleteItemsElement) {\n        var itemElements = autocompleteItemsElement.getElementsByTagName(\"div\");\n\n        if (e.keyCode == 40) {\n          e.preventDefault();\n          /*If the arrow DOWN key is pressed, increase the focusedItemIndex variable:*/\n\n          focusedItemIndex = focusedItemIndex !== itemElements.length - 1 ? focusedItemIndex + 1 : 0;\n          /*and and make the current item more visible:*/\n\n          setActive(itemElements, focusedItemIndex);\n        } else if (e.keyCode == 38) {\n          e.preventDefault();\n          /*If the arrow UP key is pressed, decrease the focusedItemIndex variable:*/\n\n          focusedItemIndex = focusedItemIndex !== 0 ? focusedItemIndex - 1 : focusedItemIndex = itemElements.length - 1;\n          /*and and make the current item more visible:*/\n\n          setActive(itemElements, focusedItemIndex);\n        } else if (e.keyCode == 13) {\n          /* If the ENTER key is pressed and value as selected, close the list*/\n          e.preventDefault();\n\n          if (focusedItemIndex > -1) {\n            closeDropDownList();\n          }\n        }\n      } else {\n        if (e.keyCode == 40) {\n          /* Open dropdown list again */\n          var event = document.createEvent('Event');\n          event.initEvent('input', true, true);\n          inputElement.dispatchEvent(event);\n        }\n      }\n    });\n\n    function setActive(items, index) {\n      if (!items || !items.length) return false;\n\n      for (var i = 0; i < items.length; i++) {\n        items[i].classList.remove(\"autocomplete-active\");\n      }\n      /* Add class \"autocomplete-active\" to the active element*/\n\n\n      items[index].classList.add(\"autocomplete-active\"); // Change input value and notify\n\n      inputElement.value = currentItems[index].properties.formatted;\n      callback(currentItems[index]);\n    }\n\n    function closeDropDownList() {\n      var autocompleteItemsElement = containerElement ? containerElement.querySelector(\".autocomplete-items\") : null;\n\n      if (autocompleteItemsElement) {\n        containerElement ? containerElement.removeChild(autocompleteItemsElement) : null;\n      }\n\n      focusedItemIndex = -1;\n    }\n\n    function addIcon(buttonElement) {\n      var svgElement = document.createElementNS(\"http://www.w3.org/2000/svg\", 'svg');\n      svgElement.setAttribute('viewBox', \"0 0 24 24\");\n      svgElement.setAttribute('height', \"24\");\n      var iconElement = document.createElementNS(\"http://www.w3.org/2000/svg\", 'path');\n      iconElement.setAttribute(\"d\", \"M19 6.41L17.59 5 12 10.59 6.41 5 5 6.41 10.59 12 5 17.59 6.41 19 12 13.41 17.59 19 19 17.59 13.41 12z\");\n      iconElement.setAttribute('fill', 'currentColor');\n      svgElement.appendChild(iconElement);\n      buttonElement.appendChild(svgElement);\n    }\n    /* Close the autocomplete dropdown when the document is clicked.\r\n      Skip, when a user clicks on the input field */\n\n\n    document.addEventListener(\"click\", function (e) {\n      if (e.target !== inputElement) {\n        closeDropDownList();\n      } else if (containerElement !== null && !containerElement.querySelector(\".autocomplete-items\")) {\n        // open dropdown list again\n        var event = document.createEvent('Event');\n        event.initEvent('input', true, true);\n        inputElement.dispatchEvent(event);\n      }\n    });\n  };\n\n  return GeoapifyAddressAutoComplete;\n}();\n\nexports.GeoapifyAddressAutoComplete = GeoapifyAddressAutoComplete;\n\n//# sourceURL=webpack://pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad/./GeoapifyAddressAutoComplete/index.ts?");

/***/ })

/******/ });
if (window.ComponentFramework && window.ComponentFramework.registerControl) {
	ComponentFramework.registerControl('ans.address.GeoapifyAddressAutoComplete', pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.GeoapifyAddressAutoComplete);
} else {
	var ans = ans || {};
	ans.address = ans.address || {};
	ans.address.GeoapifyAddressAutoComplete = pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad.GeoapifyAddressAutoComplete;
	pcf_tools_652ac3f36e1e4bca82eb3c1dc44e6fad = undefined;
}